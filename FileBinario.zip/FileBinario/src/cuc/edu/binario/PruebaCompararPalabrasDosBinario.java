
package cuc.edu.binario;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author slayk
 */
public class PruebaCompararPalabrasDosBinario {
     
    public static void main(String[] args) {
        
        try {
            CompararPalabrasDosBinario file = new CompararPalabrasDosBinario("archivo.bin", "archivo2.bin");
            System.out.println("son : "+file.numPalabra());
        } catch (IOException ex) {
            Logger.getLogger(PruebaCompararPalabrasDosBinario.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
    }
    
}
