
package cuc.edu.binario;

import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author slayk
 */
public class PruebaDeterminarBMP {
    public static void main(String[] args) {
    
        try {
            File archivo = new File("img1.bmp");
            DeterminarBMP.lectorBMP(archivo);
        } catch (IOException ex) {
            Logger.getLogger(PruebaDeterminarBMP.class.getName()).log(Level.SEVERE, null, ex);
        }
    
    }
}
