
package cuc.edu.binario;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

/**
 *
 * @author slayk
 */
public class CompararPalabrasDosBinario {
    
    private String archivoBinario1;
    private String archivoBinario2;

    public CompararPalabrasDosBinario(String archivoBinario1, String archivoBinario2) {
        this.archivoBinario1 = archivoBinario1;
        this.archivoBinario2 = archivoBinario2;
    }
   
    public String numPalabra() throws FileNotFoundException, IOException {
        FileInputStream entrada = new FileInputStream(archivoBinario1);
        FileInputStream entrada2 = new FileInputStream(archivoBinario2);

        String cadena = "";
        String cadena2 = "";
        while (entrada.available() != 0) {
            int byteLeido = entrada.read();
            char caracterLeido = (char) byteLeido;
            if (caracterLeido == '\n') {
                cadena += caracterLeido;

                while (entrada2.available() != 0) {
                    int byteLeido2 = entrada2.read();
                    char caracterLeido2 = (char) byteLeido2;
                    if (caracterLeido2 == '\n') {
                        cadena2 += caracterLeido2;
                        System.out.println(cadena);
                        System.out.println(cadena2);
                        if (cadena.equals(cadena2)) {
                            return "la cadena 1 es igual";
                        } else {
                            return "la cadena 1 NO es igual";
                        }
                    }

                }

            }

        }

 return "callate mlp";   
    }
}
