
package cuc.edu.binario;

import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author slayk
 */
public class PruebaNumeroLineasByte {
    public static void main(String[] args) {
        
        try {
        //    File file = new File("ArchivoTexto.bit");
            NumeroLineasByte file1 = new NumeroLineasByte("archivo.bin");
            int tamanno = file1.contarLineas();
            System.out.println("el numero de lineas es: "+tamanno);
        } catch (IOException ex) {
            Logger.getLogger(PruebaNumeroLineasByte.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        }
     
}
