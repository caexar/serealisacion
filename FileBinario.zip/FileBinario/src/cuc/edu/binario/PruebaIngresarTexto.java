
package cuc.edu.binario;

import java.io.IOException;

/**
 *
 * @author slayk
 */
public class PruebaIngresarTexto {
    public static void main(String[] args) {
       
//        try {
//            //un dolor pa otro dia
//            IngresarTexto ingresar = new IngresarTexto("ArchivoTexto.bin");
//            System.out.println("iniciando....");
//            String texto = IngresarTexto.capturarTexto();
//            IngresarTexto.capturarTexto("escribiendo texto a las 3 de la mannana", archivo);
//            IngresarTexto.capturarTexto("ya chao", archivo);
//            IngresarTexto.capturarTexto("raund 2", archivo);
//            System.out.println("finalizado...");
//        } catch (IOException ex) {
//            Logger.getLogger(PruebaIngresarTexto.class.getName()).log(Level.SEVERE, null, ex);
//        }

         try {
            //lectura
    //      File file = new File("ArchivoTexto.bin");
            IngresarTexto ingresar = new IngresarTexto("ArchivoTexto.bin");
            String texto = ingresar.capturarTexto();
    //      System.out.println("sirve: "+texto);

        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
        
    }
    
}
