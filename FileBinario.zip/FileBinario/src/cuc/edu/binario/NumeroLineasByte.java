
package cuc.edu.binario;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

/**
 *
 * @author slayk
 */
public class NumeroLineasByte {

    private String archivoPrueba;
    //contructor
    public NumeroLineasByte(String archivoPrueba) {
        this.archivoPrueba = archivoPrueba;
    }
    
    //metodo
        public int contarLineas() throws FileNotFoundException, IOException{
        
        FileInputStream entrada = new FileInputStream(archivoPrueba);
        int contador = 0;
            while (entrada.available() != 0) {   
            int tem = entrada.read();
            char caracter = (char) tem;
                if (caracter == '\n') {
                    contador++;
                }
          
  //           System.out.println("el caracter es: "+caracter+" el tamaño es: "+tem);
  //           System.out.println("el contqdor va por: "+contador);
            }
   
            entrada.close();
            return contador;

    }
    
}
