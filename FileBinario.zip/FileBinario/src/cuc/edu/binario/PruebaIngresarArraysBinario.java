
package cuc.edu.binario;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author slayk
 */
public class PruebaIngresarArraysBinario {
    public static void main(String[] args) {
        
        try {
            //crear un vector de enteros
            
            //pedimos el tamaño del vector
            int tamañoVector = Integer.parseInt(JOptionPane.showInputDialog("ingrese el tamaño del vector"));
            
            
            // colocamos la variable capturada en el vector
            int [] vector = new int [tamañoVector];
            
            
            // recorremos el vector 
            for (int i = 0; i < vector.length; i++) {
               
                int numerosGuardar= Integer.parseInt(JOptionPane.showInputDialog("ingrese el numero a guardar"));
                
                vector [i] = numerosGuardar;
            }
            
            
            
            
            //crear el objeto con su constructor que sea el nombre del archivo a crear
            IngresarArraysBinario vector01 = new IngresarArraysBinario("archivoVector");
            
      
            //llamar el metodo del objeto para guardar el vector y como parametro tiene que tener el vector
            vector01.guardarVectorEnBinario(vector);
        } catch (IOException ex) {
            Logger.getLogger(PruebaIngresarArraysBinario.class.getName()).log(Level.SEVERE, null, ex);
        }
            
            
         
        
        
        
    }
    
}
