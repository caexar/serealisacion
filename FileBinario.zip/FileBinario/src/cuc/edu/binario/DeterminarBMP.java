/*1. Diseñe un programa que tome un archivo y determine si es una imagen de tipo BMP. 
Un archivo de tipo BMP tiene sus dos primeros bytes con los valores B y M (0x42 y 0x4D).*/
package cuc.edu.binario;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;

/**
 *
 * @author slayk
 */
public class DeterminarBMP {
    
    public static  boolean lectorBMP(File archivo) 
            throws FileNotFoundException, IOException {
        FileInputStream entrada = new FileInputStream(archivo);
        //lector 1er byte
        int byte1 = entrada.read();
            char letra1 = (char) byte1;
            System.out.println(byte1);
        //lector 2do byte
        int byte2 = entrada.read();
            char letra2 = (char) byte2;
            //comparacion
            if (byte1 == 'B' && byte2 == 'M') {
                System.out.println("true");
            return true;
        }else{
                System.out.println("falce");
            return false;
            }
        
        
    }
    
}
