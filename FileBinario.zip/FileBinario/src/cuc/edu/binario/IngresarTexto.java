
package cuc.edu.binario;


import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Scanner;

/**
 *
 * @author slayk
 */
public class IngresarTexto {
    
    private String archivo;

    public IngresarTexto(String archivo) {
        this.archivo = archivo;
    }

    public String capturarTexto() throws IOException{
        Scanner leer = new Scanner(System.in);
        System.out.println("ingrese texto");
        String texto = leer.nextLine();
//      System.out.println(texto);
        
        FileOutputStream escribir = new FileOutputStream(archivo);
//      System.out.println("leido");

        byte[] bytes1 = texto.getBytes();
        escribir.write(bytes1);
        escribir.close();
    return texto;
    } 
    
    
}
