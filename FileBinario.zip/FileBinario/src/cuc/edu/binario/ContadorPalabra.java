
package cuc.edu.binario;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

/**
 *
 * @author slayk
 */
public class ContadorPalabra {
    
    private String archivoCadena;

    public ContadorPalabra(String archivoCadena) {
        this.archivoCadena = archivoCadena;
    }
    //se come una palabra de cada linea
    public int numPalabra() throws FileNotFoundException, IOException{
        //leer el file
        FileInputStream entrada = new FileInputStream("archivo.bin");
       //leer cadena
       //contar lineas
       int contadorLineas = 0;
            String cadena = "";
            int contador = 0;
            while (entrada.available() != 0 ) {                
                int byteLeido = entrada.read();
                char caracterLeido = (char) byteLeido;
                if (caracterLeido == '\n') {
                    contadorLineas++;
                }
                if (caracterLeido == ' ') {//si se encuentra con un caracter basi
                    contador++;
//                    if (caracterLeido == '\n') {
//                        contador++;
//                    }
                     System.out.println("Cadena leída: "+cadena);
                   
                    cadena = "";
                } else {
                cadena += caracterLeido; //al no encontrar un espacio vacio salta el else y guarda la variable en cadena
                }

    }entrada.close();
            System.out.println(contador);
            System.out.println(contadorLineas);
//            contador=+ contador+1;
            int contador2 = contador + contadorLineas;
            return contador2;
    }
    
}
