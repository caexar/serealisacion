
package cuc.edu.binario;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Arrays;

/**
 *
 * @author slayk
 */
public class IngresarArraysBinario {
    String archivoBinario;

    public IngresarArraysBinario(String archivoBinario) {
        this.archivoBinario = archivoBinario;
    }
    
    public String guardarVectorEnBinario(int vector[]) throws FileNotFoundException, IOException{
        
        
        //(1)
        //crear  el FileOutPut Para escribir en el archivo binario
        FileOutputStream salida = new FileOutputStream(archivoBinario);
        //(2)
        //convertir el vector en un String y guardarlo en una variable
        String salidaString= Arrays.toString(vector);
        //(3)
        // crear un vector de char y guardar la variable String donde almaceno los numeros del vector
        char [] vectorSalida = salidaString.toCharArray();
        //(4)
        //hacer un ciclo que recorra el array CHAR y vaya guardando cada numero en la posicion I dentro de una variable (Actual)
        for (int i = 0; i < vectorSalida.length; i++) {
            char actual = vectorSalida[i];
        //(5)
        //Invocar el metodo Write del FileOutPut y colocar la variable actual que esta guardando el recorrido del vector CHAR
            salida.write(actual);                    
        }
        //(6)
        //Cerrar el flujo del File
        salida.close();           
        //(7)
        //retornar mensaje
        return "Vector guardado exitosamente";
        
        
    }
    
}
