
package cuc.edu.binario;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author slayk
 */
public class PruebaContadorPalabra {
    public static void main(String[] args) {
        
        try {
            ContadorPalabra contador = new ContadorPalabra("archivo.bin");
            System.out.println("el numero de palabra es: "+contador.numPalabra());
        } catch (IOException ex) {
            Logger.getLogger(PruebaContadorPalabra.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
}
