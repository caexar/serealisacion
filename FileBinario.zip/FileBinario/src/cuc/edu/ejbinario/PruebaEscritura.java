
package cuc.edu.ejbinario;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author slayk
 */
public class PruebaEscritura {
    public static void main(String[] args) {
        
        try {
            ArrayList<Double> numeros = new ArrayList<>();
            numeros.add(5.8);
            numeros.add(5.8);
            numeros.add(5.7);
            numeros.add(5.7);
            numeros.add(5.5);
            numeros.add(5.6);
            System.out.println("vector: "+numeros);
            
            //iniciar escritura
            System.out.println("iniciando escritura archivo....");
            File archivo1 = new File("vector.dat");
            ArchivosBinarios.guardarVector(numeros, archivo1);
            System.out.println("archivo almacenado exitosamente");
        } catch (IOException ex) {
            Logger.getLogger(PruebaEscritura.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
