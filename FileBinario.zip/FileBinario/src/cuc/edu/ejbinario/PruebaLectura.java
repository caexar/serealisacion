
package cuc.edu.ejbinario;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author slayk
 */
public class PruebaLectura {
    public static void main(String[] args) {
        try {
            File archivo1 = new File("vector.dat");
            System.out.println("inicia lectura del archivo..");
            ArrayList<Double> numerosLeidos = ArchivosBinarios.leerVector(archivo1);
            System.out.println("archivo leido exitosamente");
            System.out.println("lista de numeros leida: "+numerosLeidos);
            System.out.println("dato:"+numerosLeidos.get(0));
//            double valor1 = numerosLeidos.get(2);
//            double valor2 = numerosLeidos.get(3);
//            System.out.println("suma: "+(valor1 + valor2));
        } catch (IOException ex) {
            Logger.getLogger(PruebaLectura.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
