
package cuc.edu.ejbinario;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

/**
 *
 * @author slayk
 */
public class ArchivosBinarios {
    //guardar el vector
    
    public static void guardarVector(ArrayList<Double> listado, File archivo) 
            throws FileNotFoundException, IOException{
        FileOutputStream output = new FileOutputStream(archivo);
        String salida = listado.toString();
        char[] vectorSalida = salida.toCharArray();
        for (int i = 0; i < vectorSalida.length; i++) {
            char actual = vectorSalida[i];
            output.write(actual);
            
        } 
    }
    //Leer el vector
    public static ArrayList<Double> leerVector(File archivo) 
            throws FileNotFoundException, IOException{
        FileInputStream input = new FileInputStream(archivo);
        ArrayList<Double> salida = new ArrayList<>();
        //Lectura del archivo
        String cadenaLectura = "";
        int dato = 0;
        while (dato != -1) {            
            dato = input.read();
            if (dato != -1){
                cadenaLectura += (char) dato;
            }
        }
        input.close();
        //formato de la entrada
        cadenaLectura = cadenaLectura.substring(1, cadenaLectura.length() -1);
        cadenaLectura = cadenaLectura.replace(" ", "");
        String[] vectorLectura = cadenaLectura.split(",");
        //almacenar los datos en el Arraylist
        for (int i = 0; i < vectorLectura.length; i++) {
            String actual = vectorLectura[i];
            salida.add(Double.parseDouble(actual));
        }
        return salida;
    }
}
