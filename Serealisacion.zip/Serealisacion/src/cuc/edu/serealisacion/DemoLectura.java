
package cuc.edu.serealisacion;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author cceveric
 */
public class DemoLectura {
    public static void main(String[] args) {
        
        File archivoEntrada = new File("archivodato.obj");
        try {
            FileInputStream flujoEntrada = new FileInputStream(archivoEntrada);
            ObjectInputStream entrada = new ObjectInputStream(flujoEntrada);
            //lectura
            String cadena = entrada.readUTF();
            System.out.println("cadena leida: "+cadena);
            System.out.println("cadena leida: "+entrada.readUTF());
            System.out.println("cadena leida: "+entrada.readUTF());
            Object objetoLeido = entrada.readObject();
            ArrayList<Integer> listaLeida = (ArrayList<Integer>) objetoLeido;
            System.out.println("lista leida: "+listaLeida);
            
            //cerrar flujo
            entrada.close();
            flujoEntrada.close();
        } catch (FileNotFoundException ex) {
            Logger.getLogger(DemoLectura.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(DemoLectura.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(DemoLectura.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
