
package cuc.edu.serealisacion;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutput;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author cceveric
 */
public class DemoEscritura {
    public static void main(String[] args) {
        
        String cadena1 = "primera cxadena del arhcivo";
        String cadena2 = "segunda cxadena del arhcivo";
        String cadena3 = "tercera cxadena del arhcivo";
        File archivoSalida = new File("archivodato.obj");
        try {
            FileOutputStream flujoSalida = new FileOutputStream(archivoSalida);
            ObjectOutputStream salida = new ObjectOutputStream(flujoSalida);
            //escritura
            System.out.println("inicializando archivo");
            salida.writeUTF(cadena1);
            salida.writeUTF(cadena2);
            salida.writeUTF(cadena3);
            ArrayList<Integer> lista = new ArrayList<>();
            lista.add(453);
            lista.add(123);
            lista.add(124);
            lista.add(234);
            lista.add(345);
            lista.add(456);
            salida.writeObject(lista);
            //cerrar flujo
            salida.close();
            flujoSalida.close();
            
            System.out.println("escrito");
        } catch (FileNotFoundException ex) {
            Logger.getLogger(DemoEscritura.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(DemoEscritura.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
}
